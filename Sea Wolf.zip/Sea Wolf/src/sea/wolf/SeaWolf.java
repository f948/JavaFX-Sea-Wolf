/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sea.wolf;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class SeaWolf extends Application {
    
         // set up the scene 
    static Canvas canvas = new Canvas(1000, 625);
    static GraphicsContext context = canvas.getGraphicsContext2D();
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root,1000,625);
    Timer timer = new Timer();
    static Random rand = new Random();
    
    final static Image battleshipImg = new Image("https://thumbs.dreamstime.com/t/warship-11725853.jpg");
    final static Image crosshairImg = new Image("https://st.depositphotos.com/1216158/5057/v/450/depositphotos_50572099-stock-illustration-crosshair-reticle.jpg");
    final static Image torpedoImg =  new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_5S7VrZKF_ndHKR16q8FPFwoCD_ibAryniA&usqp=CAU");
    
    
    static double triggerX=500,triggerY=312.5;
    static ArrayList<Ship> ships = new ArrayList<>();
    static ArrayList<Torpedo> torpedoes = new ArrayList<>();
    static ArrayList<Mine> mines = new ArrayList<>();
    static boolean playerCanFire=true;
    static int i,j;
    static int randomX,startX,startSide,row,lastRow=0;
    
    public static class Ship{
        
        double x;
        double y;
        int velocityX;
        boolean hit;
        final int width;
        final int height;
        
        public Ship(double x,double y, int velocityX){
            this.x=x;
            this.y=y;
            this.velocityX=velocityX;
            this.hit=false;
            this.width=60;
            this.height=20;
        }
    }
    

    
    public static class Torpedo{
            
        double x;
        double y;
        boolean hit;
        final int width;
        final int height;
        
        public Torpedo(double x,double y){
            this.x=x;
            this.y=y;
            this.hit=false;
            this.width=4;
            this.height=20;
        }
    }
    
    public static class Mine{
            
        double x;
        double y;
        boolean hit;

        
        public Mine(double x,double y){
            this.x=x;
            this.y=y;
            this.hit=false;
        }
    }
    
    public static void generateShip(){
        
        randomX=rand.nextInt(6)+5;
        startSide = rand.nextInt(2);
        row=rand.nextInt(11);
        
        while(row==lastRow){
            row=rand.nextInt(11);
        }
        
        lastRow=row;
        
        if(startSide==0){
            startX=-100;
        }
        
        else if(startSide==1){
            startX=1100;
            randomX=-randomX;
        }
        
        ships.add(new Ship(startX,row*30+50,randomX));
    }
    
    public static void generateMine(){
        
        mines.add(new Mine(-100,400));
    }
    
    public static void updateScreen(){
        
        // clear screen 
        context.clearRect(0,0,1000,625);

        // draw crosshair 
        context.drawImage(crosshairImg,triggerX-20,triggerY-20,40,40);
        
        // draw ships
        for(i=0;i<=ships.size()-1;i++){
            
            if(!ships.get(i).hit){
                context.drawImage(battleshipImg,ships.get(i).x,ships.get(i).y,80,30);
                
                for(j=0;j<=torpedoes.size()-1;j++){
                    
                    if(!torpedoes.get(j).hit && ((torpedoes.get(j).x+1.5 <=ships.get(i).x+80 && torpedoes.get(j).x+1.5>=ships.get(i).x && torpedoes.get(j).y<=ships.get(i).y+30 && torpedoes.get(j).y>=ships.get(i).y) || (torpedoes.get(j).x+1.5 <=ships.get(i).x+80 && torpedoes.get(j).x+1.5>=ships.get(i).x && torpedoes.get(j).y+10<=ships.get(i).y+30 && torpedoes.get(j).y+10>=ships.get(i).y) || (torpedoes.get(j).x+1.5 <=ships.get(i).x+80 && torpedoes.get(j).x+1.5>=ships.get(i).x && torpedoes.get(j).y+20<=ships.get(i).y+30 && torpedoes.get(j).y+20>=ships.get(i).y))){
                        torpedoes.get(j).hit=true;
                        ships.get(i).hit=true;
                    }
                }
                
                ships.get(i).x+=ships.get(i).velocityX;
            
            }
        }
        
        context.setFill(Color.BLACK);
        
        // draw torpedoes 
        for(i=0;i<=torpedoes.size()-1;i++){
            
            if(!torpedoes.get(i).hit){
                
                context.fillRect(torpedoes.get(i).x,torpedoes.get(i).y,4,20);
                torpedoes.get(i).y+=-8;
            }
        }
        
        // draw mines
        for(i=0;i<=mines.size()-1;i++){
            
            if(!mines.get(i).hit){
                context.fillOval(mines.get(i).x,mines.get(i).y,10,10);
                
                for(j=0;j<=torpedoes.size()-1;j++){
                    
                     if(!torpedoes.get(j).hit && (Math.pow((torpedoes.get(j).x+1.5-mines.get(i).x),2) +Math.pow((torpedoes.get(j).y-mines.get(i).y),2)<=100 || Math.pow((torpedoes.get(j).x+1.5-mines.get(i).x),2) +Math.pow((torpedoes.get(j).y+10-mines.get(i).y),2)<=100 || Math.pow((torpedoes.get(j).x+1.5-mines.get(i).x),2) +Math.pow((torpedoes.get(j).y+20-mines.get(i).y),2)<=100)){
                        torpedoes.get(j).hit=true;
                        mines.get(i).hit=true;
                    }
                }
                
                mines.get(i).x+=5;
            
            }
        }
        
        deleteObjects();
    }
    
    public static void deleteObjects(){
        
        for(i=0;i<=ships.size()-1;i++){
            if(ships.get(i).x>1200 || ships.get(i).x<-200 ){
                ships.remove(ships.get(i));
            }
        }
        
        for(i=0;i<=torpedoes.size()-1;i++){
            if(torpedoes.get(i).y<0){
                torpedoes.remove(torpedoes.get(i));
            }
        }
        
        for(i=0;i<=mines.size()-1;i++){
            if(mines.get(i).x>1200){
                mines.remove(mines.get(i));
            }
        }
    }
    
    @Override
    public void start(Stage primaryStage) {
        
        timer.scheduleAtFixedRate(new TimerTask(){
            
            @Override
            public void run() {
                updateScreen();
            }
            
        },0,50);
        
        timer.scheduleAtFixedRate(new TimerTask(){
            
            @Override
            public void run() {
                generateShip();
            }
            
        },0,3000);
        
        timer.scheduleAtFixedRate(new TimerTask(){
            
            @Override
            public void run() {
                generateMine();
            }
            
        },0,2500);
        
        canvas.setOnMouseMoved(new EventHandler<MouseEvent>() {
           
            @Override
            public void handle(MouseEvent e) {
           
                triggerX=e.getX();
                triggerY=e.getY();
                
               
            }
        });
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.W) {
                
                
                if(playerCanFire){
                    
                   
                    
                    torpedoes.add(new Torpedo(triggerX,625));
                    playerCanFire=false;
                
                
                    timer.schedule(new TimerTask() {

                     @Override
                     public void run() {
                            playerCanFire=true;
                        }
                    
                        
                
                    },2000);
                    
                }
            }
        });
        
        primaryStage.setTitle("Sea Wolf");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
